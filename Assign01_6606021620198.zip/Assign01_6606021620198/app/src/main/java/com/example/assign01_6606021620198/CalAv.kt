package com.example.assign01_6606021620198

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class CalAv : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_cal_av)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val etScore = findViewById<EditText>(R.id.etScore)
        val btnCalG = findViewById<Button>(R.id.btnCalG)
        val btnB1 = findViewById<Button>(R.id.btnB1)
        val textR = findViewById<TextView>(R.id.textR2)

        btnCalG.setOnClickListener {
            val s = etScore.text.toString().toDoubleOrNull() ?: 0.0
            val resultText =
                    "Your score : $s\n" +
                    "You got grade : ${grade(s)}\n"

            textR.text = resultText
            etScore.setText("0")

        }

        btnB1.setOnClickListener {
            finish()
        }


    }
    private fun grade(score: Double): String {
        return  if(score >= 80) "A"
        else if (score >= 75) "B+"
        else if (score >= 70) "B"
        else if (score >= 65) "C+"
        else if (score >= 60) "C"
        else if (score >= 55) "D+"
        else if (score >= 50) "D"
        else "F"
    }
}
