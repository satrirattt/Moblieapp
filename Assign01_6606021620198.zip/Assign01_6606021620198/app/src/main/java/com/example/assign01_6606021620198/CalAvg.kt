package com.example.assign01_6606021620198

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class CalAvg : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_cal_avg)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val etNum1 = findViewById<EditText>(R.id.etNum1)
        val etNum2 = findViewById<EditText>(R.id.etNum2)
        val etNum3 = findViewById<EditText>(R.id.etNum3)
        val etNum4 = findViewById<EditText>(R.id.etNum4)

        val btnCalG = findViewById<Button>(R.id.btnCalG)
        val btnB1 = findViewById<Button>(R.id.btnB1)
        val textR = findViewById<TextView>(R.id.textR)

        btnCalG.setOnClickListener {
            val n1 = etNum1.text.toString().toDoubleOrNull() ?: 0.0
            val n2 = etNum2.text.toString().toDoubleOrNull() ?: 0.0
            val n3 = etNum3.text.toString().toDoubleOrNull() ?: 0.0
            val n4 = etNum4.text.toString().toDoubleOrNull() ?: 0.0
            val total = n1 + n2 + n3 + n4
            val average = total / 4
            val resultText =
                    "Num 1 : ${formatNumber(n1)}\n" +
                    "Num 2 : ${formatNumber(n2)}\n" +
                    "Num 3 : ${formatNumber(n3)}\n" +
                    "Num 4 : ${formatNumber(n4)}\n" +
                    "Total : $total\n" +
                    "Average : $average"

            textR.text = resultText

            etNum1.setText("0")
            etNum2.setText("0")
            etNum3.setText("0")
            etNum4.setText("0")
        }

        btnB1.setOnClickListener {
            finish()
        }
    }
    private fun formatNumber(num: Double): String {
        return if (num % 1 == 0.0) {
            num.toInt().toString()
        } else {
            num.toString()
        }
    }
}