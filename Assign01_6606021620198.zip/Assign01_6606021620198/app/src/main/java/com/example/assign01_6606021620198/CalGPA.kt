package com.example.assign01_6606021620198

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class CalGPA : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_cal_gpa)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val etGPA1 = findViewById<EditText>(R.id.etGPA1)
        val etGPA2 = findViewById<EditText>(R.id.etGPA2)
        val etGPA3 = findViewById<EditText>(R.id.etGPA3)
        val etGPA4 = findViewById<EditText>(R.id.etGPA4)

        val btnCalG3 = findViewById<Button>(R.id.btnCalG3)
        val btnB2 = findViewById<Button>(R.id.btnB2)
        val textR1 = findViewById<TextView>(R.id.textR4)

        btnCalG3.setOnClickListener {
            val g1 = etGPA1.text.toString().uppercase()
            val g2 = etGPA2.text.toString().uppercase()
            val g3 = etGPA3.text.toString().uppercase()
            val g4 = etGPA4.text.toString().uppercase()
            val p1 = gpa(g1)
            val p2 = gpa(g2)
            val p3 = gpa(g3)
            val p4 = gpa(g4)

            val totalpoint = p1 + p2 + p3 + p4
            val pointavg = totalpoint / 12.0
            val resultText = 
                    "Subject 1 : Grade $g1 : Points : $p1\n" +
                    "Subject 2 : Grade $g2 : Points : $p2\n" +
                    "Subject 3 : Grade $g3 : Points : $p3\n" +
                    "Subject 4 : Grade $g4 : Points : $p4\n" +
                    "Total Points : $totalpoint , Total Credits : 12\n" +
                    "Grade Points Average(GPA) : ${String.format("%.1f", pointavg)}"

            textR1.text = resultText

            etGPA1.setText("")
            etGPA2.setText("")
            etGPA3.setText("")
            etGPA4.setText("")
        }

        btnB2.setOnClickListener {
            finish()
        }
    }

    private fun gpa(grade: String): Double {
        return if (grade == "A") {
            4.0 * 3
        } else if (grade == "B") {
            3.0 * 3
        } else if (grade == "C") {
            2.0 * 3
        } else if (grade == "D") {
            1.0 * 3
        } else {
            0.0 * 3
        }
    }
}