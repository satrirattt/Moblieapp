package com.example.assign01_6606021620198

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class CalVa : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_cal_va)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val etPrice = findViewById<EditText>(R.id.etPrice)
        val btnCalV = findViewById<Button>(R.id.btnCalV)
        val btnB = findViewById<Button>(R.id.btnB)
        val textR = findViewById<TextView>(R.id.textR3)
        btnCalV.setOnClickListener {
            val p = etPrice.text.toString().toDoubleOrNull() ?: 0.0
            val vat = p * 0.07
            val total = p + vat
            val resultText =
                    "Product price : ${String.format("%,.2f", p)}\n" +
                    "Product vat : ${String.format("%,.2f", vat)}\n" +
                    "Product Total : ${String.format("%,.2f", total)}\n"

            textR.text = resultText
            etPrice.setText("0")

        }

        btnB.setOnClickListener {
            finish()
        }
    }
}
