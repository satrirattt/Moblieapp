package com.example.assign01_6606021620198

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val btnAvg : Button = findViewById<Button>(R.id.btnAvg)
        val btnG : Button = findViewById<Button>(R.id.btnG)
        val btnV : Button = findViewById<Button>(R.id.btnV)
        val btnGPA : Button = findViewById<Button>(R.id.btnGPA)
        val btnExit : Button = findViewById<Button>(R.id.btnExit)

        btnAvg.setOnClickListener {
            Toast.makeText(this@MainActivity, "Avg" , Toast.LENGTH_SHORT).show()
            val launchAvg = Intent(this@MainActivity, CalAvg::class.java )
            startActivity(launchAvg)
        }
        btnG.setOnClickListener {
            Toast.makeText(this@MainActivity, "Grade" , Toast.LENGTH_SHORT).show()
            val launchAv = Intent(this@MainActivity, CalAv::class.java )
            startActivity(launchAv)
        }
        btnV.setOnClickListener {
            Toast.makeText(this@MainActivity, "Vat" , Toast.LENGTH_SHORT).show()
            val launchVa = Intent(this@MainActivity, CalVa::class.java )
            startActivity(launchVa)
        }
        btnGPA.setOnClickListener {
            Toast.makeText(this@MainActivity, "GPA" , Toast.LENGTH_SHORT).show()
            val launchGPA = Intent(this@MainActivity, CalGPA::class.java )
            startActivity(launchGPA)
        }
        btnExit.setOnClickListener {
            Toast.makeText(this@MainActivity, "Exit", Toast.LENGTH_SHORT).show()
            finish();
        }
    }
}