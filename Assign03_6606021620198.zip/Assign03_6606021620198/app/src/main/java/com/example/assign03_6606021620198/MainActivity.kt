package com.example.assign03_6606021620198

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat



class MainActivity : AppCompatActivity() {

    data class Student(val id: String, val name: String, val imageRes: Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.activity_main)
        val root = findViewById<View>(R.id.rootLayout)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(0, systemBars.top, 0, systemBars.bottom)
            insets
        }
        val listView = findViewById<ListView>(R.id.listViewStudents)

        val studentList = arrayListOf(
            Student("65-60216-1001-1", "ATTITAYA LAKSANSUANG", R.drawable.s1),
            Student("65-60216-1002-2", "CHAIYANA TOUMJAN", R.drawable.s1),
            Student("65-60216-1003-3", "CHAIYANAN PUNYURA", R.drawable.s1),
            Student("65-60216-1004-4", "JETNIPAT PRAKONNA", R.drawable.s1),
            Student("65-60216-1005-5", "KAMIN KAEWHOM", R.drawable.s1),
            Student("65-60216-1006-6", "KANTHIDA INTARAS", R.drawable.s1)

        )


        val adapter = object : ArrayAdapter<Student>(this, R.layout.row_student, studentList) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val rowView = LayoutInflater.from(context).inflate(R.layout.row_student, parent, false)

                val txtId = rowView.findViewById<TextView>(R.id.txtId)
                val txtName = rowView.findViewById<TextView>(R.id.txtName)
                val img = rowView.findViewById<ImageView>(R.id.imgStudent)

                val student = studentList[position]
                txtId.text = student.id
                txtName.text = student.name
                img.setImageResource(student.imageRes)

                return rowView
            }
        }

        listView.adapter = adapter


        listView.setOnItemClickListener { _, _, position, _ ->
            val s = studentList[position]
            Toast.makeText(this, "ID: ${s.id}  \n" +
                    "Name: ${s.name}", Toast.LENGTH_SHORT).show()
        }
    }
}

