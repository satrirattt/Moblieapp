package com.example.assign04_6606021620198_

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.PopupMenu
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.assign04_6606021620198.AboutActivity

class MainActivity : AppCompatActivity() {
    private lateinit var btnFood: Button
    private lateinit var btnQty: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        btnFood = findViewById(R.id.btnFood)
        btnQty = findViewById(R.id.btnQty)


        btnFood.setOnClickListener {

            val popup = PopupMenu(this, btnFood)

            // เพิ่มเมนูแบบเขียนในโค้ด
            popup.menu.add("กะเพราหมูสับ + ไข่ดาว 50 บาท")
            popup.menu.add("ผคะน้าหมูกรอบ + ไข่เจียว 60 บาท")
            popup.menu.add("ผัดไทกุ้งสด 70 บาท")
            popup.menu.add("ข้าวมันไก่ 40 บาท")

            popup.setOnMenuItemClickListener { item ->
                btnFood.text = item.title
                true
            }

            popup.show()
        }


        btnQty.setOnClickListener {

            val popup = PopupMenu(this, btnQty)

            popup.menu.add("- 1 -")
            popup.menu.add("- 2 -")
            popup.menu.add("- 3 -")
            popup.menu.add("- 4 -")
            popup.menu.add("- 5 -")

            popup.setOnMenuItemClickListener { item ->
                btnQty.text = item.title
                true
            }

            popup.show()
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {

            R.id.menu_about -> {
                val intent = Intent(this, AboutActivity::class.java)
                startActivity(intent)
                return true
            }

            R.id.menu_exit -> {
                finish()
                return true
            }
        }

        return super.onOptionsItemSelected(item)
    }


}
