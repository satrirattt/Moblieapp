package com.example.assign05_6606021620198

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val dataList = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val r1 = findViewById<EditText>(R.id.r1)
        val r2 = findViewById<EditText>(R.id.r2)
        val btnSave = findViewById<Button>(R.id.bsave)
        val btnResult = findViewById<Button>(R.id.bresult)


        btnSave.setOnClickListener {
            val item = r1.text.toString()
            val price = r2.text.toString()

            if (item.isNotEmpty() && price.isNotEmpty()) {
                val text = "$item - $price บาท"
                dataList.add(text)

                r1.text.clear()
                r2.text.clear()

                Toast.makeText(this, "บันทึกแล้ว", Toast.LENGTH_SHORT).show()
            }
        }


        btnResult.setOnClickListener {
            val intent = Intent(this, Result::class.java)
            intent.putStringArrayListExtra("data", dataList)
            startActivity(intent)
        }
    }
}