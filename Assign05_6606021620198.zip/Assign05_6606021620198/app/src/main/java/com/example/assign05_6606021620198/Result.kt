package com.example.assign05_6606021620198

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class Result : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_result)

        val listView = findViewById<ListView>(R.id.listView)
        val btnBack = findViewById<Button>(R.id.bback)


        val dataList = intent.getStringArrayListExtra("data")


        if (dataList != null) {
            val adapter = ArrayAdapter(
                this,
                android.R.layout.simple_list_item_1,
                dataList
            )
            listView.adapter = adapter
        }


        btnBack.setOnClickListener {
            finish()
        }
    }
}